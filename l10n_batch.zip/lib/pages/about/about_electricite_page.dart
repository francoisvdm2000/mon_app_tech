import 'package:flutter/material.dart';

import '../../app/ui/widgets.dart'; // SectionCard, copyToClipboard
import 'package:mon_app_tech/l10n_gen/app_localizations.dart';

class AboutElectricitePage extends StatefulWidget {
  const AboutElectricitePage({super.key});

  @override
  State<AboutElectricitePage> createState() => _AboutElectricitePageState();
}

class _AboutElectricitePageState extends State<AboutElectricitePage> {
  final _scroll = ScrollController();

  final _kBasics = GlobalKey();
  final _kConnectors = GlobalKey();
  final _kMonoTri = GlobalKey();
  final _kPowerTable = GlobalKey();
  final _kSafety = GlobalKey();
  final _kChecklist = GlobalKey();

  final _kKvaConversion = GlobalKey();

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  void _goTo(GlobalKey key) {
    final ctx = key.currentContext;
    if (ctx == null) return;
    Scrollable.ensureVisible(
      ctx,
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOutCubic,
      alignment: 0.06,
    );
  }

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);
    final bottom = MediaQuery.of(context).viewPadding.bottom;

    return Scaffold(
      appBar: AppBar(title: const Text('Électrique — repères terrain')),
      body: SafeArea(
        bottom: true,
        child: SingleChildScrollView(
          controller: _scroll,
          padding: EdgeInsets.fromLTRB(16, 12, 16, 16 + bottom),
          child: Column(
            children: [
              _TocCard(
                onCopy: () {
                  copyToClipboard(context, loc.elecTocCopyText);
                },
                items: [
                  _TocItem('1) Bases (W, A, V, kW)',
                      onTap: () => _goTo(_kBasics)),
                  _TocItem('2) Connecteurs (Schuko / P17 / PowerCON)',
                      onTap: () => _goTo(_kConnectors)),
                  _TocItem('3) Mono / Tri (ce que ça change)',
                      onTap: () => _goTo(_kMonoTri)),
                  _TocItem('4) Table rapide (16A → 400A)',
                      onTap: () => _goTo(_kPowerTable)),
                  _TocItem(loc.elecKvaTitle,
                      onTap: () => _goTo(_kKvaConversion)),
                  _TocItem('6) Sécurité & pièges terrain',
                      onTap: () => _goTo(_kSafety)),
                  _TocItem('6) Checklist', onTap: () => _goTo(_kChecklist)),
                ],
              ),
              const SizedBox(height: 12),
              _Anchor(key: _kBasics),
              const _Section1Basics(),
              const SizedBox(height: 12),
              _Anchor(key: _kConnectors),
              const _Section2Connectors(),
              const SizedBox(height: 12),
              _Anchor(key: _kMonoTri),
              const _Section3MonoTri(),
              const SizedBox(height: 12),
              _Anchor(key: _kPowerTable),
              const _Section4PowerTable(),
              const SizedBox(height: 12),
              _Anchor(key: _kKvaConversion),
              const _SectionKvaConversion(),
              const SizedBox(height: 12),
              _Anchor(key: _kSafety),
              const _Section5Safety(),
              const SizedBox(height: 12),
              _Anchor(key: _kChecklist),
              _Section6Checklist(
                onCopy: () {
                  copyToClipboard(context, loc.elecTocCopyText);
                },
              ),
              const SizedBox(height: 18),
              const _FooterNote(),
            ],
          ),
        ),
      ),
    );
  }
}

/// =======================
/// TOC
/// =======================

class _TocCard extends StatelessWidget {
  const _TocCard({
    required this.items,
    required this.onCopy,
  });

  final List<_TocItem> items;
  final VoidCallback onCopy;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: AppLocalizations.of(context).commonTocTitle,
      icon: Icons.electrical_services,
      trailing: IconButton(
        tooltip: AppLocalizations.of(context).commonCopySummaryTooltip,
        icon: const Icon(Icons.copy, color: Colors.white70),
        onPressed: onCopy,
      ),
      child: Column(
        children: items
            .map(
              (it) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Material(
                  color: const Color(0xFF0B0B0B),
                  borderRadius: BorderRadius.circular(12),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: it.onTap,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 12),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              it.label,
                              style: TextStyle(
                                color: Colors.white.withValues(alpha: 0.92),
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                          Icon(Icons.chevron_right,
                              color: Colors.white.withValues(alpha: 0.55)),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            )
            .toList(),
      ),
    );
  }
}

class _TocItem {
  _TocItem(this.label, {required this.onTap});
  final String label;
  final VoidCallback onTap;
}

/// =======================
/// SECTIONS
/// =======================

class _SectionKvaConversion extends StatelessWidget {
  const _SectionKvaConversion();

  static const _rows = <int>[
    16,
    20,
    25,
    32,
    40,
    50,
    63,
    80,
    100,
    125,
    160,
    200,
    250,
    315,
    400,
    500,
    630,
    800,
  ];

  String _kw(double v) {
    final s = v.toStringAsFixed(1);
    return s.endsWith('.0') ? s.substring(0, s.length - 2) : s;
  }

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);
    final title = loc.elecKvaTitle;
    final formula = loc.elecKvaFormula;
    final intro = loc.elecKvaIntro;
    final note = loc.elecKvaNote;

    final colKva = loc.elecKvaColKva;
    final colPf08 = loc.elecKvaColPf08;
    final colPf10 = loc.elecKvaColPf10;

    return SectionCard(
      title: title,
      icon: Icons.bolt,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$formula\n\n$intro',
            style: const TextStyle(height: 1.25),
          ),
          const SizedBox(height: 10),
          Table(
            border: TableBorder.all(color: Colors.white24),
            columnWidths: const {
              0: FlexColumnWidth(1),
              1: FlexColumnWidth(1),
              2: FlexColumnWidth(1),
            },
            children: [
              TableRow(
                decoration:
                    BoxDecoration(color: Colors.white.withValues(alpha: 0.06)),
                children: [
                  _cellHead(colKva),
                  _cellHead(colPf08),
                  _cellHead(colPf10),
                ],
              ),
              ..._rows.map((a) {
                final kva = a.toDouble();
                final kw08 = kva * 0.8;
                final kw10 = kva * 1.0;
                return TableRow(
                  children: [
                    _cell('$a'),
                    _cell(_kw(kw08)),
                    _cell(_kw(kw10)),
                  ],
                );
              }),
            ],
          ),
          const SizedBox(height: 10),
          Text(note,
              style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.7), height: 1.25)),
        ],
      ),
    );
  }

  static Widget _cellHead(String t) => Padding(
        padding: const EdgeInsets.all(8),
        child: Text(t, style: const TextStyle(fontWeight: FontWeight.w900)),
      );

  static Widget _cell(String t) => Padding(
        padding: const EdgeInsets.all(8),
        child: Text(t),
      );
}

class _Section1Basics extends StatelessWidget {
  const _Section1Basics();

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: '1) Bases (W, A, V, kW)',
      icon: Icons.calculate,
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _Callout(
            title: '3 formules utiles',
            bullet: [
              'P (W) = U (V) × I (A)',
              'I (A) = P (W) / U (V)',
              'P (kW) = P (W) / 1000',
            ],
          ),
          SizedBox(height: 10),
          _Callout(
            title: 'Repères terrain',
            bullet: [
              'Mono 230V : 16A ≈ 3,7 kW | 32A ≈ 7,4 kW | 63A ≈ 14,5 kW',
              'Tri 400V : 16A ≈ 11 kW | 32A ≈ 22 kW | 63A ≈ 44 kW',
            ],
          ),
        ],
      ),
    );
  }
}

class _Section2Connectors extends StatelessWidget {
  const _Section2Connectors();

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: '2) Connecteurs (Schuko / P17 / PowerCON)',
      icon: Icons.power,
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _Callout(
            title: 'Schuko (prises domestiques)',
            bullet: [
              'Typiquement 16A max (≈ 3,7 kW à 230V).',
              'Attention aux multiprises et rallonges : échauffement possible.',
            ],
          ),
          SizedBox(height: 10),
          _Callout(
            title: 'P17 / CEE (bleu/rouge)',
            bullet: [
              'Bleu : 230V mono (camping, petit distro).',
              'Rouge : 400V tri (distro, grandes puissances).',
            ],
          ),
          SizedBox(height: 10),
          _Callout(
            title: 'PowerCON (audio/éclairage)',
            bullet: [
              'PowerCON TRUE1 = plus “terrain” (verrouillage, IP).',
              'Vérifie la section de câble et les protections.',
            ],
          ),
        ],
      ),
    );
  }
}

class _Section3MonoTri extends StatelessWidget {
  const _Section3MonoTri();

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: '3) Mono / Tri (ce que ça change)',
      icon: Icons.device_hub,
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _Paragraph(
            "Mono = une phase + neutre (230V). Tri = 3 phases (400V entre phases).",
          ),
          SizedBox(height: 10),
          _Callout(
            title: 'Pièges fréquents',
            bullet: [
              'Déséquilibre des phases (une phase surcharge).',
              'Neutre qui chauffe si grosses harmoniques (LED, dimmers).',
              'Terre absente/douteuse sur certains sites.',
            ],
          ),
          SizedBox(height: 10),
          _Callout(
            title: 'Méthode simple',
            bullet: [
              'Répartis les grosses charges sur L1/L2/L3.',
              'Surveille le neutre si beaucoup de LED.',
              'Mesure au clamp si possible.',
            ],
          ),
        ],
      ),
    );
  }
}

class _Section4PowerTable extends StatelessWidget {
  const _Section4PowerTable();

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: '4) Table rapide (16A → 400A)',
      icon: Icons.table_chart,
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _Subtitle('Mono 230V (≈ U×I)'),
          _CodeBox(
            '16A ≈ 3,7 kW\n'
            '32A ≈ 7,4 kW\n'
            '63A ≈ 14,5 kW\n'
            '125A ≈ 28,8 kW\n'
            '200A ≈ 46 kW\n',
          ),
          SizedBox(height: 10),
          _Subtitle('Tri 400V (≈ √3×U×I)'),
          _CodeBox(
            '16A ≈ 11 kW\n'
            '32A ≈ 22 kW\n'
            '63A ≈ 44 kW\n'
            '125A ≈ 86 kW\n'
            '200A ≈ 138 kW\n'
            '400A ≈ 277 kW\n',
          ),
          SizedBox(height: 10),
          _Callout(
            title: 'Important',
            bullet: [
              'Ce sont des ordres de grandeur (cosφ, harmoniques, pertes).',
              'Toujours valider protections + sections + température.',
            ],
          ),
        ],
      ),
    );
  }
}

class _Section5Safety extends StatelessWidget {
  const _Section5Safety();

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: '6) Sécurité & pièges terrain',
      icon: Icons.health_and_safety,
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _Callout(
            title: 'À ne pas faire',
            bullet: [
              'Chainer multiprises / rallonges en vrac.',
              'Mélanger des phases sans savoir.',
              '“Bridger” une terre douteuse.',
            ],
          ),
          SizedBox(height: 10),
          _Callout(
            title: 'Signaux d’alerte',
            bullet: [
              'Odeur de chaud, prises tièdes, déclenchements répétés.',
              'Tension qui chute (brown-out).',
              'Disjoncteur “fatigué” ou inadapté.',
            ],
          ),
        ],
      ),
    );
  }
}

class _Section6Checklist extends StatelessWidget {
  const _Section6Checklist({required this.onCopy});
  final VoidCallback onCopy;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: '6) Checklist',
      icon: Icons.checklist,
      trailing: IconButton(
        tooltip: 'Copier',
        icon: const Icon(Icons.copy, color: Colors.white70),
        onPressed: onCopy,
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _Subtitle('Rapide'),
          _BulletList(
            [
              'Type d’alim dispo (mono/tri) + calibre (A).',
              'Répartition phases (charges principales).',
              'Protections (diff/disj) et état du tableau.',
              'Câbles : section / longueur / échauffement.',
              'Terre : OK ? (testeur si possible).',
            ],
          ),
        ],
      ),
    );
  }
}

/// =======================
/// UI bits
/// =======================

class _Anchor extends StatelessWidget {
  const _Anchor({super.key});

  @override
  Widget build(BuildContext context) => const SizedBox(height: 1);
}

class _FooterNote extends StatelessWidget {
  const _FooterNote();

  @override
  Widget build(BuildContext context) {
    return Text(
      "Note : ce contenu est un aide-mémoire terrain. Sur un site réel, respecte toujours les normes, "
      "les prescriptions du lieu et les protections en place.",
      style:
          TextStyle(color: Colors.white.withValues(alpha: 0.55), height: 1.25),
    );
  }
}

class _Subtitle extends StatelessWidget {
  const _Subtitle(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(fontWeight: FontWeight.w900),
    );
  }
}

class _Paragraph extends StatelessWidget {
  const _Paragraph(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(text, style: const TextStyle(height: 1.25));
  }
}

class _Callout extends StatelessWidget {
  const _Callout({required this.title, required this.bullet});

  final String title;
  final List<String> bullet;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withValues(alpha: 0.10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          _BulletList(bullet),
        ],
      ),
    );
  }
}

class _BulletList extends StatelessWidget {
  const _BulletList(this.items);
  final List<String> items;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: items
          .map(
            (t) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('•  ',
                      style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.85))),
                  Expanded(
                      child: Text(t, style: const TextStyle(height: 1.25))),
                ],
              ),
            ),
          )
          .toList(),
    );
  }
}

class _CodeBox extends StatelessWidget {
  const _CodeBox(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF0B0B0B),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withValues(alpha: 0.10)),
      ),
      child: Text(
        text,
        style: const TextStyle(
          fontFamily: 'monospace',
          height: 1.25,
        ),
      ),
    );
  }
}
