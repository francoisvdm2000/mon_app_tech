import 'package:flutter/material.dart';

const _kAccent = Color(0xFF9C27B0);

class _UhfBand {
  final String name;
  final String freqRange;
  final String status;
  final Color statusColor;
  final String description;
  final String? examples;
  final bool isFreePR; // libre sans autorisation

  const _UhfBand({
    required this.name,
    required this.freqRange,
    required this.status,
    required this.statusColor,
    required this.description,
    this.examples,
    this.isFreePR = false,
  });
}

const _bands = [
  _UhfBand(
    name: 'VHF Bas',
    freqRange: '174–230 MHz',
    status: 'Limité',
    statusColor: Colors.orangeAccent,
    description: 'Ancienne bande TV analogique. Quelques systèmes HF utilisent cette plage. Moins commune en événementiel.',
    examples: 'Certains anciens systèmes Sennheiser, Shure',
  ),
  _UhfBand(
    name: 'UHF — Bloc TV',
    freqRange: '470–694 MHz',
    status: 'Pro (autorisation)',
    statusColor: Color(0xFF9C27B0),
    description: 'Principale bande pour micros HF professionnels en France. Partage avec la TNT. '
        'Requiert une autorisation ANFR pour usage commercial. Usage libre pour la production audiovisuelle sous conditions.',
    examples: 'Shure Axient, Sennheiser 2000, Sony DWX, Audio-Technica 3000',
  ),
  _UhfBand(
    name: 'Dividende numérique',
    freqRange: '694–790 MHz',
    status: 'INTERDIT',
    statusColor: Colors.redAccent,
    description: 'Bande allouée aux réseaux mobiles 4G/5G en France depuis 2017. '
        'Tout matériel sans-fil audio dans cette bande est illégal depuis cette date.',
    examples: null,
  ),
  _UhfBand(
    name: 'ISM / SRD 863 MHz',
    freqRange: '863–865 MHz',
    status: 'Libre (10 mW)',
    statusColor: Colors.greenAccent,
    description: 'Bande libre en Europe (SRD — Short Range Device). Pas d\'autorisation requise. '
        'Limite de puissance : 10 mW ERP, 25 kHz de largeur de bande.',
    examples: 'Certains systèmes d\'entr��e de gamme, télécommandes',
    isFreePR: true,
  ),
  _UhfBand(
    name: 'DECT',
    freqRange: '1880–1900 MHz',
    status: 'Libre (250 mW)',
    statusColor: Colors.greenAccent,
    description: 'Standard dédié à la voix sans-fil. Pas d\'interférences avec WiFi/Bluetooth. '
        'Utilisé pour les systèmes de conférence, intercom et certains micros sans-fil.',
    examples: 'Bosch CCS-800 Ultro, Sennheiser SpeechLine, Beyerdynamic Quinta',
    isFreePR: true,
  ),
  _UhfBand(
    name: 'Micro num. 2.4 GHz',
    freqRange: '2400–2484 MHz',
    status: 'Libre (100 mW)',
    statusColor: Colors.blueAccent,
    description: 'Bande ISM, libre sans autorisation. Sujette aux interférences WiFi et Bluetooth. '
        'Convient aux petites productions, éviter les grandes salles avec WiFi dense.',
    examples: 'Shure GLX-D, Line6 XD-V, Sennheiser EW-D (variante 2.4G)',
    isFreePR: true,
  ),
  _UhfBand(
    name: 'Sans-fil 5.8 GHz',
    freqRange: '5725–5850 MHz',
    status: 'Limité (FR)',
    statusColor: Colors.orangeAccent,
    description: 'Non disponible pour WiFi en France, mais certains systèmes propriétaires utilisent '
        'cette plage. Vérifier la conformité ARCEP de chaque ��quipement.',
    examples: 'Certains systèmes IEM haut de gamme',
  ),
];

class RfUhfBandsPage extends StatelessWidget {
  const RfUhfBandsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewPadding.bottom;

    return Scaffold(
      backgroundColor: const Color(0xFF0D0D14),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0D0D14),
        surfaceTintColor: Colors.transparent,
        scrolledUnderElevation: 0,
        title: const Text('Bandes UHF / VHF',
            style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 0.2)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Divider(height: 1, color: Colors.white.withValues(alpha: 0.08)),
        ),
      ),
      body: SafeArea(
        bottom: true,
        child: ListView(
          padding: EdgeInsets.fromLTRB(16, 16, 16, 24 + bottom),
          children: [
            // ── Vue d'ensemble ────────────────────────────────────────────────
            _Card(
              icon: Icons.bar_chart_rounded,
              title: 'Vue d\'ensemble — France',
              child: Column(
                children: [
                  _OverviewBar(
                    label: '174–470 MHz',
                    sublabel: 'VHF / transitoire',
                    color: Colors.white30,
                    widthFactor: 0.15,
                  ),
                  const SizedBox(height: 6),
                  _OverviewBar(
                    label: '470–694 MHz',
                    sublabel: 'UHF pro (autorisation)',
                    color: _kAccent,
                    widthFactor: 0.55,
                  ),
                  const SizedBox(height: 6),
                  _OverviewBar(
                    label: '694–790 MHz',
                    sublabel: '4G/5G — INTERDIT',
                    color: Colors.redAccent,
                    widthFactor: 0.25,
                  ),
                  const SizedBox(height: 6),
                  _OverviewBar(
                    label: '863–865 MHz',
                    sublabel: 'ISM libre',
                    color: Colors.greenAccent,
                    widthFactor: 0.08,
                  ),
                  const SizedBox(height: 6),
                  _OverviewBar(
                    label: '1880–1900 MHz',
                    sublabel: 'DECT libre',
                    color: Colors.greenAccent,
                    widthFactor: 0.10,
                  ),
                  const SizedBox(height: 6),
                  _OverviewBar(
                    label: '2.4 GHz',
                    sublabel: 'ISM (WiFi + micros num.)',
                    color: Colors.blueAccent,
                    widthFactor: 0.40,
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _Legend(color: _kAccent, label: 'Pro (autorisation)'),
                      const SizedBox(width: 12),
                      _Legend(color: Colors.greenAccent, label: 'Libre'),
                      const SizedBox(width: 12),
                      _Legend(color: Colors.redAccent, label: 'Interdit'),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // ── Bandes détaillées ─────────────────────────────────────────────
            ..._bands.map((band) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _BandTile(band: band),
                )),

            const SizedBox(height: 4),

            // ── Recommandations ───────────────────────────────────────────────
            _Card(
              icon: Icons.tips_and_updates_rounded,
              title: 'Conseils pour le choix de bande',
              child: const Column(
                children: [
                  _TipRow(
                    icon: Icons.star_rounded,
                    color: _kAccent,
                    text: '470–694 MHz : optimal pour les productions pro. Large choix de fréquences, bon comportement RF. Déclarer l\'usage à l\'ANFR pour les événements professionnels.',
                  ),
                  _TipRow(
                    icon: Icons.warning_amber_rounded,
                    color: Colors.redAccent,
                    text: 'Vérifiez impérativement que votre matériel est hors bande 694–790 MHz. Les anciens systèmes non revendus post-2017 sont illégaux sur scène.',
                  ),
                  _TipRow(
                    icon: Icons.mic_rounded,
                    color: Colors.greenAccent,
                    text: 'DECT (1880–1900 MHz) est idéal pour les systèmes de conférence : bande dédiée, pas d\'interférences WiFi/BT.',
                  ),
                  _TipRow(
                    icon: Icons.info_outline_rounded,
                    color: Colors.blueAccent,
                    text: 'Les systèmes 2.4 GHz sont pratiques mais sensibles aux environnements WiFi denses. À éviter dans les grandes salles de congrès.',
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Text(
              'Source : ANFR / ARCEP — Réglementation française.\n'
              'Les règles peuvent varier selon les pays.\n'
              'Vérifiez toujours la conformité de votre matériel.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 11,
                color: Colors.white.withValues(alpha: 0.28),
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OverviewBar extends StatelessWidget {
  final String label;
  final String sublabel;
  final Color color;
  final double widthFactor;

  const _OverviewBar({
    required this.label,
    required this.sublabel,
    required this.color,
    required this.widthFactor,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 100,
          child: Text(
            label,
            style: TextStyle(
              fontFamily: 'monospace',
              fontSize: 10,
              color: Colors.white.withValues(alpha: 0.55),
            ),
          ),
        ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              FractionallySizedBox(
                widthFactor: widthFactor.clamp(0.04, 1.0),
                child: Container(
                  height: 12,
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.30),
                    borderRadius: BorderRadius.circular(3),
                    border: Border.all(color: color.withValues(alpha: 0.70)),
                  ),
                ),
              ),
              const SizedBox(height: 2),
              Text(
                sublabel,
                style: TextStyle(
                  fontSize: 10,
                  color: color.withValues(alpha: 0.80),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _BandTile extends StatelessWidget {
  final _UhfBand band;
  const _BandTile({required this.band});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF161622),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withValues(alpha: 0.07)),
      ),
      padding: const EdgeInsets.all(14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 4,
            height: 60,
            margin: const EdgeInsets.only(right: 12),
            decoration: BoxDecoration(
              color: band.statusColor,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            band.name,
                            style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 14,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            band.freqRange,
                            style: TextStyle(
                              fontFamily: 'monospace',
                              fontSize: 11,
                              color: Colors.white.withValues(alpha: 0.50),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: band.statusColor.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(7),
                        border: Border.all(
                            color: band.statusColor.withValues(alpha: 0.40)),
                      ),
                      child: Text(
                        band.status,
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          color: band.statusColor,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  band.description,
                  style: TextStyle(
                    fontSize: 12.5,
                    color: Colors.white.withValues(alpha: 0.60),
                    height: 1.4,
                  ),
                ),
                if (band.examples != null) ...[
                  const SizedBox(height: 6),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.devices_rounded,
                          color: Colors.white.withValues(alpha: 0.35), size: 14),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          band.examples!,
                          style: TextStyle(
                            fontSize: 11.5,
                            color: Colors.white.withValues(alpha: 0.40),
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Legend extends StatelessWidget {
  final Color color;
  final String label;
  const _Legend({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
                color: color, borderRadius: BorderRadius.circular(2))),
        const SizedBox(width: 5),
        Text(label,
            style: TextStyle(
                fontSize: 11, color: Colors.white.withValues(alpha: 0.55))),
      ],
    );
  }
}

class _TipRow extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String text;
  const _TipRow({required this.icon, required this.color, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(text,
                style: TextStyle(
                    fontSize: 13,
                    color: Colors.white.withValues(alpha: 0.70),
                    height: 1.4)),
          ),
        ],
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final IconData icon;
  final String title;
  final Widget child;

  const _Card({required this.icon, required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF161622),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withValues(alpha: 0.07)),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(children: [
            Icon(icon, color: Colors.white70, size: 20),
            const SizedBox(width: 10),
            Expanded(
              child: Text(title,
                  style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                      letterSpacing: 0.1)),
            ),
          ]),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}
