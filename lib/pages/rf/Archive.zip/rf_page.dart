import 'package:flutter/material.dart';
import 'package:mon_app_tech/l10n_gen/app_localizations.dart';

import '../../services/subscription_service.dart';
import '../subscription_page.dart';
import 'rf_wifi_24_page.dart';
import 'rf_wifi_5_page.dart';
import 'rf_coexistence_page.dart';
import 'rf_antenna_page.dart';
import 'rf_uhf_bands_page.dart';
import 'rf_im3_page.dart';
import 'rf_wifi_scan_page.dart';
import 'rf_scan_log_page.dart';

const _kAccent = Color(0xFF9C27B0);

// Outils gratuits : Bandes UHF/VHF, Calculateur d'Antenne
// Outils Pro     : tous les autres

class RfPage extends StatefulWidget {
  const RfPage({super.key});
  @override
  State<RfPage> createState() => _RfPageState();
}

class _RfPageState extends State<RfPage> {
  bool _isPro = false;

  @override
  void initState() {
    super.initState();
    _checkAccess();
  }

  Future<void> _checkAccess() async {
    final ok = await SubscriptionService.hasAccess(SubscriptionCategory.sonRf);
    if (!mounted) return;
    setState(() => _isPro = ok);
  }

  Future<void> _goToSubscription() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            const SubscriptionPage(category: SubscriptionCategory.sonRf),
      ),
    );
    _checkAccess();
  }

  Widget _sectionLabel(String text) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 16, 0, 8),
      child: Row(
        children: [
          Expanded(
              child: Divider(
                  color: Colors.white.withValues(alpha: 0.10), height: 1)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text(
              text.toUpperCase(),
              style: const TextStyle(
                color: _kAccent,
                fontSize: 10,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.5,
              ),
            ),
          ),
          Expanded(
              child: Divider(
                  color: Colors.white.withValues(alpha: 0.10), height: 1)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D14),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0D0D14),
        surfaceTintColor: Colors.transparent,
        scrolledUnderElevation: 0,
        title: const Text('RF & Sans-fil',
            style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 0.2)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child:
              Divider(height: 1, color: Colors.white.withValues(alpha: 0.08)),
        ),
      ),
      body: ListView(
        padding: EdgeInsets.fromLTRB(
            16, 8, 16, 24 + MediaQuery.paddingOf(context).bottom),
        children: [
          // ── Micros HF & Antennes ──────────────────────────────────────────
          _sectionLabel('Micros HF & Antennes'),
          // GRATUIT
          _RfToolTile(
            icon: Icons.settings_input_antenna_rounded,
            title: 'Bandes UHF / VHF',
            subtitle:
                'Bandes légales France (ANFR), UHF 470–694 MHz, dividende numérique, DECT, ISM 863 MHz.',
            free: true,
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const RfUhfBandsPage())),
          ),
          const SizedBox(height: 10),
          // GRATUIT
          _RfToolTile(
            icon: Icons.radio_rounded,
            title: 'Calculateur d\'Antenne',
            subtitle:
                'Fréquence → λ/4, λ/2, 5λ/8. Facteur de vélocité pour câbles coaxiaux. Références UHF/WiFi.',
            free: true,
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const RfAntennaPage())),
          ),
          // ── Calculs HF ────────────────────────────────────────────────────
          _sectionLabel('Calculs HF'),
          _RfToolTile(
            icon: Icons.scatter_plot_rounded,
            title: 'Intermodulation IM3',
            subtitle:
                'Calcule 2Fi−Fj pour 2 à 16 fréquences. Détecte les produits qui tombent sur vos canaux.',
            pro: true,
            locked: !_isPro,
            onTap: _isPro
                ? () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const RfIm3Page()))
                : _goToSubscription,
          ),
          // ── WiFi ──────────────────────────────────────────────────────────
          _sectionLabel('WiFi'),
          _RfToolTile(
            icon: Icons.wifi_rounded,
            title: 'Canaux WiFi 2.4 GHz',
            subtitle:
                '13 canaux, chevauchements visuels, simulateur de conflits. Canaux non-conflictuels 1, 6, 11.',
            pro: true,
            locked: !_isPro,
            onTap: _isPro
                ? () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const RfWifi24Page()))
                : _goToSubscription,
          ),
          const SizedBox(height: 10),
          _RfToolTile(
            icon: Icons.wifi_find_rounded,
            title: 'Canaux WiFi 5 GHz',
            subtitle:
                'Bandes UNII-1/2A/2C, DFS, canaux disponibles en France. Non-chevauchants à 80 MHz.',
            pro: true,
            locked: !_isPro,
            onTap: _isPro
                ? () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const RfWifi5Page()))
                : _goToSubscription,
          ),
          // ── Coexistence ───────────────────────────────────────────────────
          _sectionLabel('Coexistence'),
          _RfToolTile(
            icon: Icons.signal_cellular_alt_rounded,
            title: 'Coexistence 2.4 GHz',
            subtitle:
                'Qui partage la bande : WiFi, Bluetooth, Zigbee, micros numériques, DMX sans-fil, vidéo. Conflits typiques.',
            pro: true,
            locked: !_isPro,
            onTap: _isPro
                ? () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const RfCoexistencePage()))
                : _goToSubscription,
          ),
          // ── Scan & Terrain ────────────────────────────────────────────────
          _sectionLabel('Scan & Terrain'),
          _RfToolTile(
            icon: Icons.wifi_find_rounded,
            title: 'Scan WiFi',
            subtitle:
                'Analyse les réseaux WiFi environnants : canaux, RSSI, bandes 2.4/5 GHz. Visualisation occupation du spectre.',
            free: true,
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const RfWifiScanPage())),
          ),
          const SizedBox(height: 10),
          _RfToolTile(
            icon: Icons.radar_rounded,
            title: 'Journal de Scan RF',
            subtitle:
                'Relevé manuel des fréquences : niveau signal, statut (libre/borderline/occupé), notes terrain.',
            free: true,
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const RfScanLogPage())),
          ),
        ],
      ),
    );
  }
}

// ── Tile ──────────────────────────────────────────────────────────────────────

class _Badge extends StatelessWidget {
  final String label;
  final Color color;
  const _Badge({required this.label, required this.color});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: color.withValues(alpha: 0.28)),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 9,
            fontWeight: FontWeight.w800,
            color: color,
            letterSpacing: 0.7,
          ),
        ),
      );
}

class _RfToolTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final bool locked;
  final bool free;
  final bool pro;

  const _RfToolTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.locked = false,
    this.free = false,
    this.pro = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF161622),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withValues(alpha: 0.07)),
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(20),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onTap,
          splashColor: _kAccent.withValues(alpha: 0.10),
          highlightColor: _kAccent.withValues(alpha: 0.04),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Stack(
                  children: [
                    Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        color:
                            _kAccent.withValues(alpha: locked ? 0.07 : 0.14),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Icon(icon,
                          color:
                              _kAccent.withValues(alpha: locked ? 0.35 : 1.0),
                          size: 26),
                    ),
                    if (locked)
                      Positioned(
                        right: 0,
                        bottom: 0,
                        child: Container(
                          width: 18,
                          height: 18,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.12),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(
                                color: Colors.white.withValues(alpha: 0.18)),
                          ),
                          child: Icon(Icons.lock_rounded,
                              size: 10,
                              color: Colors.white.withValues(alpha: 0.65)),
                        ),
                      ),
                  ],
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              title,
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w700,
                                color: Colors.white
                                    .withValues(alpha: locked ? 0.50 : 1.0),
                                letterSpacing: 0.1,
                              ),
                            ),
                          ),
                          if (pro || locked) ...[
                            const SizedBox(width: 6),
                            _Badge(
                              label: AppLocalizations.of(context).subscriptionCategorySonRfShort,
                              color: _kAccent,
                            ),
                            const SizedBox(width: 4),
                            _Badge(
                              label: AppLocalizations.of(context).subscriptionProShort,
                              color: const Color(0xFF7C4DFF),
                            ),
                          ] else if (free) ...[
                            const SizedBox(width: 6),
                            const _Badge(
                              label: 'GRATUIT',
                              color: Color(0xFF00C853),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: Colors.white
                              .withValues(alpha: locked ? 0.28 : 0.50),
                          fontSize: 12.5,
                          height: 1.35,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Icon(
                  locked ? Icons.lock_rounded : Icons.chevron_right_rounded,
                  color: locked
                      ? Colors.white.withValues(alpha: 0.18)
                      : _kAccent.withValues(alpha: 0.65),
                  size: locked ? 18 : 22,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
