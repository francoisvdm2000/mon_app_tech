import 'package:flutter/material.dart';

import '../../app/ui/widgets.dart'; // SectionCard, MiniPill, copyToClipboard
import 'package:mon_app_tech/l10n_gen/app_localizations.dart';

class AboutDmxPage extends StatefulWidget {
  const AboutDmxPage({super.key});

  @override
  State<AboutDmxPage> createState() => _AboutDmxPageState();
}

class _AboutDmxPageState extends State<AboutDmxPage> {
  final _scrollCtrl = ScrollController();

  // Sections (sommaire interne -> scroll)
  final _k1Basics = GlobalKey();
  final _k2Frame = GlobalKey();
  final _k3Cabling = GlobalKey();
  final _k4Termination = GlobalKey();
  final _k4bRdm = GlobalKey();
  final _k5Troubleshooting = GlobalKey();
  final _k6ArtNet = GlobalKey();
  final _k7Sacn = GlobalKey();
  final _k8Compare = GlobalKey();
  final _k9Diagrams = GlobalKey();
  final _k10Checklist = GlobalKey();

  void _goTo(GlobalKey key) {
    final ctx = key.currentContext;
    if (ctx == null) return;
    Scrollable.ensureVisible(
      ctx,
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOutCubic,
      alignment: 0.02,
    );
  }

  @override
  void dispose() {
    _scrollCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);
    final bottom = MediaQuery.of(context).viewPadding.bottom;

    return Scaffold(
      appBar: AppBar(
        title: Text(loc.aboutDmxPageTitle),
      ),
      body: SafeArea(
        bottom: true,
        child: SingleChildScrollView(
          controller: _scrollCtrl,
          padding: EdgeInsets.fromLTRB(16, 12, 16, 16 + bottom),
          child: Column(
            children: [
              _TocCard(
                onCopy: () {
                  final txt = [
                    loc.aboutDmxSummaryLine1,
                    loc.aboutDmxSummaryLine2,
                    loc.aboutDmxSummaryLine3,
                    loc.aboutDmxSummaryLine4,
                    loc.aboutDmxSummaryLine5,
                    loc.aboutDmxSummaryLine6,
                  ].join('\n');
                  copyToClipboard(context, txt);
                },
                items: [
                  _TocItem(loc.aboutDmxToc1, onTap: () => _goTo(_k1Basics)),
                  _TocItem(loc.aboutDmxToc2, onTap: () => _goTo(_k2Frame)),
                  _TocItem(loc.aboutDmxToc3, onTap: () => _goTo(_k3Cabling)),
                  _TocItem(loc.aboutDmxToc4,
                      onTap: () => _goTo(_k4Termination)),
                  _TocItem(loc.aboutDmxToc4bis, onTap: () => _goTo(_k4bRdm)),
                  _TocItem(loc.aboutDmxToc5,
                      onTap: () => _goTo(_k5Troubleshooting)),
                  _TocItem(loc.aboutDmxToc6, onTap: () => _goTo(_k6ArtNet)),
                  _TocItem(loc.aboutDmxToc7, onTap: () => _goTo(_k7Sacn)),
                  _TocItem(loc.aboutDmxToc8, onTap: () => _goTo(_k8Compare)),
                  _TocItem(loc.aboutDmxToc9, onTap: () => _goTo(_k9Diagrams)),
                  _TocItem(loc.aboutDmxToc10,
                      onTap: () => _goTo(_k10Checklist)),
                ],
              ),
              const SizedBox(height: 12),
              _Anchor(key: _k1Basics),
              const _Section1Basics(),
              const SizedBox(height: 12),
              _Anchor(key: _k2Frame),
              const _Section2Frame(),
              const SizedBox(height: 12),
              _Anchor(key: _k3Cabling),
              const _Section3Cabling(),
              const SizedBox(height: 12),
              _Anchor(key: _k4Termination),
              const _Section4TerminationSplitters(),
              const SizedBox(height: 12),
              _Anchor(key: _k4bRdm),
              const _Section4bRdm(),
              const SizedBox(height: 12),
              _Anchor(key: _k5Troubleshooting),
              const _Section5Troubleshooting(),
              const SizedBox(height: 12),
              _Anchor(key: _k6ArtNet),
              const _Section6ArtNet(),
              const SizedBox(height: 12),
              _Anchor(key: _k7Sacn),
              const _Section7Sacn(),
              const SizedBox(height: 12),
              _Anchor(key: _k8Compare),
              const _Section8Compare(),
              const SizedBox(height: 12),
              _Anchor(key: _k9Diagrams),
              const _Section9Diagrams(),
              const SizedBox(height: 12),
              _Anchor(key: _k10Checklist),
              _Section10Checklist(
                onCopy: () {
                  final txt = '''
${loc.aboutDmxChecklistCopyTitle}
☐ ${loc.aboutDmxChecklistCopyB1}
☐ ${loc.aboutDmxChecklistCopyB2}
☐ ${loc.aboutDmxChecklistCopyB3}
☐ ${loc.aboutDmxChecklistCopyB4}
☐ ${loc.aboutDmxChecklistCopyB5}
☐ ${loc.aboutDmxChecklistCopyB6}
☐ ${loc.aboutDmxChecklistCopyB7}
☐ ${loc.aboutDmxChecklistCopyB8}

${loc.aboutDmxChecklistCopyTitle2}
☐ ${loc.aboutDmxChecklistCopyB9}
☐ ${loc.aboutDmxChecklistCopyB10}
☐ ${loc.aboutDmxChecklistCopyB11}
☐ ${loc.aboutDmxChecklistCopyB12}
☐ ${loc.aboutDmxChecklistCopyB13}
'''
                      .trim();
                  copyToClipboard(context, txt);
                },
              ),
              const SizedBox(height: 18),
              _FooterNote(),
            ],
          ),
        ),
      ),
    );
  }
}

/// =======================
/// TOC (Table des matières)
/// =======================

class _TocCard extends StatelessWidget {
  const _TocCard({
    required this.items,
    required this.onCopy,
  });

  final List<_TocItem> items;
  final VoidCallback onCopy;

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);
    return SectionCard(
      title: loc.commonTocTitle,
      icon: Icons.list_alt,
      trailing: IconButton(
        tooltip: loc.commonCopySummaryTooltip,
        icon: const Icon(Icons.copy, color: Colors.white70),
        onPressed: onCopy,
      ),
      child: Column(
        children: items
            .map(
              (it) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Material(
                  color: const Color(0xFF0B0B0B),
                  borderRadius: BorderRadius.circular(12),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: it.onTap,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 12),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              it.label,
                              style: TextStyle(
                                color: Colors.white.withValues(alpha: 0.92),
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                          Icon(Icons.chevron_right,
                              color: Colors.white.withValues(alpha: 0.55)),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            )
            .toList(),
      ),
    );
  }
}

class _TocItem {
  _TocItem(this.label, {required this.onTap});
  final String label;
  final VoidCallback onTap;
}

/// =======================
/// SECTIONS (inchangées)
//  -> Tu peux garder TOUTES tes sections/painters comme avant.
/// =======================

class _Section1Basics extends StatelessWidget {
  const _Section1Basics();

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);
    return SectionCard(
      title: loc.aboutDmxS1Title,
      icon: Icons.view_stream,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              MiniPill(loc.aboutDmxS1Pill1),
              MiniPill(loc.aboutDmxS1Pill2),
              MiniPill(loc.aboutDmxS1Pill3),
            ],
          ),
          SizedBox(height: 10),
          _Paragraph(loc.aboutDmxS1Intro),
          SizedBox(height: 10),
          _Callout(
            title: loc.aboutDmxS1RememberTitle,
            bullets: [
              loc.aboutDmxS1RememberB1,
              loc.aboutDmxS1RememberB2,
              loc.aboutDmxS1RememberB3,
            ],
          ),
        ],
      ),
    );
  }
}

// --- Garde tes classes _Section2Frame, _Section3Cabling, etc.
// --- Garde aussi tes CustomPainter (_DmxTimingPainter, _SacnMulticastPainter, etc.)
// --- Rien à changer dedans : ce n’est PAS de la recherche.

class _Section2Frame extends StatelessWidget {
  const _Section2Frame();

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);

    return SectionCard(
      title: loc.aboutDmxS2Title,
      icon: Icons.timeline,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              MiniPill(loc.aboutDmxS2PillBreak),
              MiniPill(loc.aboutDmxS2PillStartCode),
              MiniPill(loc.aboutDmxS2PillSlots512),
              MiniPill(loc.aboutDmxS2PillRefresh),
            ],
          ),
          const SizedBox(height: 10),
          _Paragraph(loc.aboutDmxS2Intro),
          const SizedBox(height: 10),
          _DiagramBox(painter: _DmxTimingPainter(loc: loc), aspect: 16 / 6),
          const SizedBox(height: 10),
          _Callout(
            title: loc.aboutDmxS2HowToReadTitle,
            bullets: [
              loc.aboutDmxS2HowToReadB1,
              loc.aboutDmxS2HowToReadB2,
              loc.aboutDmxS2HowToReadB3,
              loc.aboutDmxS2HowToReadB4,
            ],
          ),
          const SizedBox(height: 10),
          _Subtitle(loc.aboutDmxS2PracticalTitle),
          const SizedBox(height: 6),
          _BulletList(items: [
            loc.aboutDmxS2PracticalB1,
            loc.aboutDmxS2PracticalB2,
            loc.aboutDmxS2PracticalB3,
          ]),
        ],
      ),
    );
  }
}

class _Section3Cabling extends StatelessWidget {
  const _Section3Cabling();

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);

    return SectionCard(
      title: loc.aboutDmxS3Title,
      icon: Icons.cable,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              MiniPill(loc.aboutDmxS3PillRs485),
              MiniPill(loc.aboutDmxS3PillDaisyChain),
              MiniPill(loc.aboutDmxS3PillNoY),
              MiniPill(loc.aboutDmxS3Pill120ohm),
            ],
          ),
          const SizedBox(height: 10),
          _Paragraph(loc.aboutDmxS3Intro),
          const SizedBox(height: 10),
          _Subtitle(loc.aboutDmxS3TopologyTitle),
          const SizedBox(height: 6),
          _DiagramBox(painter: _DmxChainPainter(loc: loc), aspect: 16 / 7),
          const SizedBox(height: 10),
          _BulletList(items: [
            loc.aboutDmxS3TopologyB1,
            loc.aboutDmxS3TopologyB2,
            loc.aboutDmxS3TopologyB3,
          ]),
          const SizedBox(height: 10),
          _Subtitle(loc.aboutDmxS3PinoutTitle),
          const SizedBox(height: 6),
          _DiagramBox(painter: _Xlr5PinoutPainter(loc: loc), aspect: 16 / 7),
          const SizedBox(height: 10),
          _Callout(
            title: loc.aboutDmxS3CablesTitle,
            bullets: [
              loc.aboutDmxS3CablesB1,
              loc.aboutDmxS3CablesB2,
              loc.aboutDmxS3CablesB3,
            ],
          ),
        ],
      ),
    );
  }
}

class _Section4TerminationSplitters extends StatelessWidget {
  const _Section4TerminationSplitters();

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);

    return SectionCard(
      title: loc.aboutDmxS4Title,
      icon: Icons.call_split,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _Paragraph(loc.aboutDmxS4Intro),
          const SizedBox(height: 10),
          _DiagramBox(painter: _TerminatorPainter(loc: loc), aspect: 16 / 6),
          const SizedBox(height: 10),
          _Callout(
            title: loc.aboutDmxS4TerminatorTitle,
            bullets: [
              loc.aboutDmxS4TerminatorB1,
              loc.aboutDmxS4TerminatorB2,
              loc.aboutDmxS4TerminatorB3,
            ],
          ),
          const SizedBox(height: 10),
          _Subtitle(loc.aboutDmxS4SplittersTitle),
          const SizedBox(height: 6),
          _BulletList(items: [
            loc.aboutDmxS4SplittersB1,
            loc.aboutDmxS4SplittersB2,
            loc.aboutDmxS4SplittersB3,
          ]),
        ],
      ),
    );
  }
}

class _Section4bRdm extends StatelessWidget {
  const _Section4bRdm();

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);
    return SectionCard(
      title: loc.aboutDmxS4bisTitle,
      icon: Icons.settings_input_component,
      child: Text(loc.aboutDmxS4bisPlaceholder),
    );
  }
}

class _Section5Troubleshooting extends StatelessWidget {
  const _Section5Troubleshooting();

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);

    return SectionCard(
      title: loc.aboutDmxS5Title,
      icon: Icons.build_circle,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _Paragraph(loc.aboutDmxS5Intro),
          const SizedBox(height: 10),
          _Callout(
            title: loc.aboutDmxS5QuickChecksTitle,
            bullets: [
              loc.aboutDmxS5QuickB1,
              loc.aboutDmxS5QuickB2,
              loc.aboutDmxS5QuickB3,
              loc.aboutDmxS5QuickB4,
              loc.aboutDmxS5QuickB5,
            ],
          ),
          const SizedBox(height: 10),
          _Subtitle(loc.aboutDmxS5IfFlickerTitle),
          const SizedBox(height: 6),
          _BulletList(items: [
            loc.aboutDmxS5IfFlickerB1,
            loc.aboutDmxS5IfFlickerB2,
            loc.aboutDmxS5IfFlickerB3,
          ]),
          const SizedBox(height: 10),
          _Subtitle(loc.aboutDmxS5GoldenRuleTitle),
          const SizedBox(height: 6),
          _Paragraph(loc.aboutDmxS5GoldenRuleBody),
        ],
      ),
    );
  }
}

class _Section6ArtNet extends StatelessWidget {
  const _Section6ArtNet();

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);

    return SectionCard(
      title: loc.aboutDmxS6Title,
      icon: Icons.router,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              MiniPill(loc.aboutDmxS6PillUdp),
              MiniPill(loc.aboutDmxS6PillNodes),
              MiniPill(loc.aboutDmxS6PillBroadcast),
              MiniPill(loc.aboutDmxS6PillUnicast),
            ],
          ),
          const SizedBox(height: 10),
          _Paragraph(loc.aboutDmxS6Intro),
          const SizedBox(height: 10),
          _DiagramBox(painter: _IpDmxPainter(loc: loc), aspect: 16 / 7),
          const SizedBox(height: 10),
          _Callout(
            title: loc.aboutDmxS6BasicsTitle,
            bullets: [
              loc.aboutDmxS6BasicsB1,
              loc.aboutDmxS6BasicsB2,
              loc.aboutDmxS6BasicsB3,
              loc.aboutDmxS6BasicsB4,
            ],
          ),
          const SizedBox(height: 10),
          _Subtitle(loc.aboutDmxS6WhenTitle),
          const SizedBox(height: 6),
          _BulletList(items: [
            loc.aboutDmxS6WhenB1,
            loc.aboutDmxS6WhenB2,
            loc.aboutDmxS6WhenB3,
          ]),
        ],
      ),
    );
  }
}

class _Section7Sacn extends StatelessWidget {
  const _Section7Sacn();

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);

    return SectionCard(
      title: loc.aboutDmxS7Title,
      icon: Icons.wifi_tethering,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              MiniPill(loc.aboutDmxS7PillE131),
              MiniPill(loc.aboutDmxS7PillMulticast),
              MiniPill(loc.aboutDmxS7PillPriority),
              MiniPill(loc.aboutDmxS7PillIgmp),
            ],
          ),
          const SizedBox(height: 10),
          _Paragraph(loc.aboutDmxS7Intro),
          const SizedBox(height: 10),
          _DiagramBox(painter: _SacnMulticastPainter(loc: loc), aspect: 16 / 7),
          const SizedBox(height: 10),
          _Callout(
            title: loc.aboutDmxS7KeyIdeasTitle,
            bullets: [
              loc.aboutDmxS7KeyIdeasB1,
              loc.aboutDmxS7KeyIdeasB2,
              loc.aboutDmxS7KeyIdeasB3,
              loc.aboutDmxS7KeyIdeasB4,
            ],
          ),
        ],
      ),
    );
  }
}

class _Section8Compare extends StatelessWidget {
  const _Section8Compare();

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);

    return SectionCard(
      title: loc.aboutDmxS8Title,
      icon: Icons.compare_arrows,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _Paragraph(loc.aboutDmxS8Intro),
          const SizedBox(height: 10),
          _Callout(
            title: loc.aboutDmxS8QuickTableTitle,
            bullets: [
              loc.aboutDmxS8QuickB1,
              loc.aboutDmxS8QuickB2,
              loc.aboutDmxS8QuickB3,
              loc.aboutDmxS8QuickB4,
            ],
          ),
          const SizedBox(height: 10),
          _Subtitle(loc.aboutDmxS8ChooseTitle),
          const SizedBox(height: 6),
          _BulletList(items: [
            loc.aboutDmxS8ChooseB1,
            loc.aboutDmxS8ChooseB2,
            loc.aboutDmxS8ChooseB3,
          ]),
        ],
      ),
    );
  }
}

class _Section9Diagrams extends StatelessWidget {
  const _Section9Diagrams();

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);
    return SectionCard(
      title: loc.aboutDmxS9Title,
      icon: Icons.schema,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _Subtitle(loc.aboutDmxS9Diagram1),
          SizedBox(height: 10),
          _DiagramBox(painter: _DmxTimingPainter(loc: loc), aspect: 16 / 6.8),
          SizedBox(height: 14),
          _Subtitle(loc.aboutDmxS9Diagram2),
          SizedBox(height: 10),
          _DiagramBox(painter: _DmxChainPainter(loc: loc), aspect: 16 / 6.8),
          SizedBox(height: 14),
          _Subtitle(loc.aboutDmxS9Diagram3),
          SizedBox(height: 10),
          _DiagramBox(painter: _TerminatorPainter(loc: loc), aspect: 16 / 6.8),
          SizedBox(height: 14),
          _Subtitle(loc.aboutDmxS9Diagram4),
          SizedBox(height: 10),
          _DiagramBox(
              painter: _SacnMulticastPainter(loc: loc), aspect: 16 / 6.8),
          SizedBox(height: 14),
          _Subtitle(loc.aboutDmxS9Diagram5),
          SizedBox(height: 10),
          _DiagramBox(painter: _IpDmxPainter(loc: loc), aspect: 16 / 6.8),
          SizedBox(height: 14),
          _Subtitle(loc.aboutDmxS9Diagram6),
          SizedBox(height: 10),
          _DiagramBox(painter: _Xlr5PinoutPainter(loc: loc), aspect: 16 / 7.8),
        ],
      ),
    );
  }
}

class _Section10Checklist extends StatelessWidget {
  const _Section10Checklist({required this.onCopy});

  final VoidCallback onCopy;

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);
    return SectionCard(
      title: loc.aboutDmxS10Title,
      icon: Icons.checklist,
      trailing: IconButton(
        tooltip: loc.aboutDmxS10CopyTooltip,
        icon: const Icon(Icons.copy, color: Colors.white70),
        onPressed: onCopy,
      ),
      child: _Callout(
        title: loc.aboutDmxS10CalloutTitle,
        bullets: [
          loc.aboutDmxS10B1,
          loc.aboutDmxS10B2,
          loc.aboutDmxS10B3,
          loc.aboutDmxS10B4,
          loc.aboutDmxS10B5,
          loc.aboutDmxS10B6,
          loc.aboutDmxS10B7,
        ],
      ),
    );
  }
}

class _FooterNote extends StatelessWidget {
  const _FooterNote();

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(context);
    return Text(
      loc.aboutDmxFooterNote,
      textAlign: TextAlign.center,
      style: TextStyle(color: Colors.white38, fontSize: 12, height: 1.35),
    );
  }
}

/// =======================
/// SMALL UI HELPERS
/// =======================

class _Anchor extends StatelessWidget {
  const _Anchor({super.key});
  @override
  Widget build(BuildContext context) => const SizedBox(height: 0);
}

class _Subtitle extends StatelessWidget {
  const _Subtitle(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: TextStyle(
        color: Colors.white.withValues(alpha: 0.92),
        fontWeight: FontWeight.w900,
        fontSize: 14.5,
      ),
    );
  }
}

class _DiagramBox extends StatelessWidget {
  const _DiagramBox({required this.painter, this.aspect = 16 / 7});

  final CustomPainter painter;
  final double aspect;

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: aspect,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: const Color(0xFF0B0B0B),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white12),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: CustomPaint(painter: painter),
        ),
      ),
    );
  }
}

class _Paragraph extends StatelessWidget {
  const _Paragraph(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: TextStyle(
        color: Colors.white.withValues(alpha: 0.80),
        height: 1.35,
        fontSize: 13.5,
      ),
    );
  }
}

class _BulletList extends StatelessWidget {
  const _BulletList({required this.items});
  final List<String> items;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: items
          .map(
            (s) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('•  ',
                      style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.80),
                          height: 1.35)),
                  Expanded(
                    child: Text(
                      s,
                      style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.80),
                          height: 1.35,
                          fontSize: 13.5),
                    ),
                  ),
                ],
              ),
            ),
          )
          .toList(),
    );
  }
}

class _Callout extends StatelessWidget {
  const _Callout({required this.title, required this.bullets});
  final String title;
  final List<String> bullets;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF0B0B0B),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white12),
      ),
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            title,
            style: TextStyle(
                color: Colors.white.withValues(alpha: 0.92),
                fontWeight: FontWeight.w900,
                fontSize: 13.5),
          ),
          const SizedBox(height: 8),
          _BulletList(items: bullets),
        ],
      ),
    );
  }
}

/// =======================
/// DIAGRAMS (CustomPainter)
/// =======================

class _DmxTimingPainter extends CustomPainter {
  const _DmxTimingPainter({required this.loc});
  final AppLocalizations loc;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = const Color(0xFF0B0B0B);
    canvas.drawRect(Offset.zero & size, bg);

    final faint = Paint()
      ..color = Colors.white.withValues(alpha: 0.16)
      ..strokeWidth = 1;

    final step = size.shortestSide / 10;
    for (double x = 0; x <= size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), faint);
    }
    for (double y = 0; y <= size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), faint);
    }

    final stroke = Paint()
      ..color = Colors.white.withValues(alpha: 0.88)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    final y = size.height * 0.55;
    final left = size.width * 0.07;
    final right = size.width * 0.93;

    canvas.drawLine(Offset(left, y), Offset(right, y), stroke);

    final xBreakEnd = size.width * 0.19;
    final xMabEnd = size.width * 0.27;
    final xStartCodeEnd = size.width * 0.34;
    final xSlotsEnd = size.width * 0.86;

    final accentBreak = Paint()
      ..color = Colors.redAccent.withValues(alpha: 0.55)
      ..strokeWidth = 8
      ..strokeCap = StrokeCap.round;

    final accentMab = Paint()
      ..color = Colors.white.withValues(alpha: 0.35)
      ..strokeWidth = 8
      ..strokeCap = StrokeCap.round;

    final accentSlots = Paint()
      ..color = Colors.white.withValues(alpha: 0.55)
      ..strokeWidth = 8
      ..strokeCap = StrokeCap.round;

    canvas.drawLine(Offset(left, y), Offset(xBreakEnd, y), accentBreak);
    canvas.drawLine(Offset(xBreakEnd, y), Offset(xMabEnd, y), accentMab);
    canvas.drawLine(
        Offset(xStartCodeEnd, y), Offset(xSlotsEnd, y), accentSlots);

    _tick(canvas, Offset(xBreakEnd, y), size);
    _tick(canvas, Offset(xMabEnd, y), size);
    _tick(canvas, Offset(xStartCodeEnd, y), size);
    _tick(canvas, Offset(xSlotsEnd, y), size);

    _Text.paintLabel(
      canvas,
      Offset(left, size.height * 0.12),
      _Text.tp(
        loc.aboutDmxPainterBreak,
        fontSize: size.shortestSide * 0.070,
        color: Colors.white.withValues(alpha: 0.92),
        weight: FontWeight.w900,
      ),
    );
    _Text.paintLabel(
      canvas,
      Offset(xBreakEnd - size.width * 0.03, size.height * 0.25),
      _Text.tp(
        loc.aboutDmxPainterMab,
        fontSize: size.shortestSide * 0.060,
        color: Colors.white.withValues(alpha: 0.90),
        weight: FontWeight.w900,
      ),
    );
    _Text.paintLabel(
      canvas,
      Offset(xMabEnd + size.width * 0.02, size.height * 0.12),
      _Text.tp(
        loc.aboutDmxPainterStartCode,
        fontSize: size.shortestSide * 0.058,
        color: Colors.white.withValues(alpha: 0.90),
        weight: FontWeight.w900,
      ),
    );
    _Text.paintLabel(
      canvas,
      Offset(xStartCodeEnd + size.width * 0.05, size.height * 0.20),
      _Text.tp(
        loc.aboutDmxPainterSlots,
        fontSize: size.shortestSide * 0.058,
        color: Colors.white.withValues(alpha: 0.92),
        weight: FontWeight.w900,
      ),
    );

    final foot = _Text.tp(
      loc.aboutDmxPainterRefresh,
      fontSize: size.shortestSide * 0.052,
      color: Colors.white.withValues(alpha: 0.85),
      weight: FontWeight.w800,
    );
    _Text.paintLabel(canvas, Offset(left, size.height * 0.74), foot);
  }

  void _tick(Canvas canvas, Offset p, Size size) {
    final paint = Paint()
      ..color = Colors.white.withValues(alpha: 0.45)
      ..strokeWidth = 2;
    canvas.drawLine(p.translate(0, -size.height * 0.10),
        p.translate(0, size.height * 0.10), paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _SacnMulticastPainter extends CustomPainter {
  const _SacnMulticastPainter({required this.loc});
  final AppLocalizations loc;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = const Color(0xFF0B0B0B);
    canvas.drawRect(Offset.zero & size, bg);

    final faint = Paint()
      ..color = Colors.white.withValues(alpha: 0.16)
      ..strokeWidth = 1;

    final step = size.shortestSide / 10;
    for (double x = 0; x <= size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), faint);
    }
    for (double y = 0; y <= size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), faint);
    }

    final stroke = Paint()
      ..color = Colors.white.withValues(alpha: 0.88)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    final src1 = Offset(size.width * 0.14, size.height * 0.30);
    final src2 = Offset(size.width * 0.14, size.height * 0.62);
    final sw = Offset(size.width * 0.40, size.height * 0.46);

    final group = Offset(size.width * 0.60, size.height * 0.46);

    final r1 = Offset(size.width * 0.86, size.height * 0.22);
    final r2 = Offset(size.width * 0.86, size.height * 0.46);
    final r3 = Offset(size.width * 0.86, size.height * 0.70);

    canvas.drawLine(src1, sw, stroke);
    canvas.drawLine(src2, sw, stroke);
    canvas.drawLine(sw, group, stroke);

    canvas.drawLine(group, r1, stroke);
    canvas.drawLine(group, r2, stroke);
    canvas.drawLine(group, r3, stroke);

    _box(canvas, size, src1, loc.aboutDmxPainterSourceA, accent: false);
    _box(canvas, size, src2, loc.aboutDmxPainterSourceB, accent: false);

    _box(canvas, size, sw, loc.aboutDmxPainterSwitchIgmp, accent: true);
    _box(canvas, size, group, loc.aboutDmxPainterMulticastUniverse,
        accent: true);

    _small(canvas, size, r1, loc.aboutDmxPainterRx);
    _small(canvas, size, r2, loc.aboutDmxPainterRx);
    _small(canvas, size, r3, loc.aboutDmxPainterRx);

    final tp = _Text.tp(
      loc.aboutDmxPainterIgmpNote,
      fontSize: size.shortestSide * 0.060,
      color: Colors.white.withValues(alpha: 0.90),
      weight: FontWeight.w900,
    );
    _Text.paintLabel(canvas, Offset(size.width * 0.08, size.height * 0.80), tp);
  }

  void _box(Canvas canvas, Size size, Offset center, String label,
      {required bool accent}) {
    final w = size.width * 0.22;
    final h = size.height * 0.22;
    final rect = Rect.fromCenter(center: center, width: w, height: h);
    final rr = RRect.fromRectAndRadius(
        rect, Radius.circular(size.shortestSide * 0.05));

    final fill = Paint()
      ..color = accent
          ? const Color(0xFF1E88E5).withValues(alpha: 0.18)
          : Colors.white.withValues(alpha: 0.08);

    final border = Paint()
      ..color = accent
          ? const Color(0xFF1E88E5).withValues(alpha: 0.60)
          : Colors.white.withValues(alpha: 0.30)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    canvas.drawRRect(rr, fill);
    canvas.drawRRect(rr, border);

    final tp = _Text.tp(
      label,
      fontSize: size.shortestSide * 0.055,
      color: Colors.white.withValues(alpha: 0.95),
      weight: FontWeight.w900,
    );
    _Text.center(canvas, rect, tp);
  }

  void _small(Canvas canvas, Size size, Offset center, String label) {
    final w = size.width * 0.08;
    final h = size.height * 0.12;
    final rect = Rect.fromCenter(center: center, width: w, height: h);
    final rr = RRect.fromRectAndRadius(
        rect, Radius.circular(size.shortestSide * 0.04));

    canvas.drawRRect(rr, Paint()..color = Colors.white.withValues(alpha: 0.07));
    canvas.drawRRect(
      rr,
      Paint()
        ..color = Colors.white.withValues(alpha: 0.20)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2,
    );

    final tp = _Text.tp(
      label,
      fontSize: size.shortestSide * 0.05,
      color: Colors.white.withValues(alpha: 0.90),
      weight: FontWeight.w900,
    );
    _Text.center(canvas, rect, tp);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _DmxChainPainter extends CustomPainter {
  const _DmxChainPainter({required this.loc});
  final AppLocalizations loc;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = const Color(0xFF0B0B0B);
    canvas.drawRect(Offset.zero & size, bg);

    final faint = Paint()
      ..color = Colors.white.withValues(alpha: 0.16)
      ..strokeWidth = 1;

    final step = size.shortestSide / 10;
    for (double x = 0; x <= size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), faint);
    }
    for (double y = 0; y <= size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), faint);
    }

    final stroke = Paint()
      ..color = Colors.white.withValues(alpha: 0.88)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    final y = size.height * 0.55;
    final x0 = size.width * 0.10;
    final dx = size.width * 0.18;

    final nodes = <_Node>[
      _Node(loc.aboutDmxPainterConsole, Offset(x0, y)),
      _Node(loc.aboutDmxPainterFix1, Offset(x0 + dx, y)),
      _Node(loc.aboutDmxPainterFix2, Offset(x0 + dx * 2, y)),
      _Node(loc.aboutDmxPainterFix3, Offset(x0 + dx * 3, y)),
      _Node(loc.aboutDmxPainterTerm120, Offset(x0 + dx * 4, y),
          isTerminator: true),
    ];

    for (int i = 0; i < nodes.length - 1; i++) {
      canvas.drawLine(nodes[i].pos, nodes[i + 1].pos, stroke);
    }

    for (final n in nodes) {
      _drawBox(canvas, size, n.pos, n.label, isTerminator: n.isTerminator);
    }

    final warnPos = Offset(size.width * 0.68, size.height * 0.18);
    final tp = _Text.tp(
      loc.aboutDmxPainterDaisyChainNote,
      fontSize: size.shortestSide * 0.07,
      color: Colors.white.withValues(alpha: 0.92),
      weight: FontWeight.w900,
    );
    _Text.paintLabel(canvas, warnPos, tp);
  }

  void _drawBox(Canvas canvas, Size size, Offset center, String label,
      {bool isTerminator = false}) {
    final w = size.width * 0.16;
    final h = size.height * 0.18;
    final rect = Rect.fromCenter(center: center, width: w, height: h);
    final rr = RRect.fromRectAndRadius(
        rect, Radius.circular(size.shortestSide * 0.05));

    final fill = Paint()
      ..color = isTerminator
          ? Colors.redAccent.withValues(alpha: 0.18)
          : Colors.white.withValues(alpha: 0.08);

    final border = Paint()
      ..color = isTerminator
          ? Colors.redAccent.withValues(alpha: 0.65)
          : Colors.white.withValues(alpha: 0.30)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    canvas.drawRRect(rr, fill);
    canvas.drawRRect(rr, border);

    final tp = _Text.tp(
      label,
      fontSize: size.shortestSide * 0.060,
      color: Colors.white.withValues(alpha: 0.95),
      weight: FontWeight.w900,
    );
    _Text.center(canvas, rect, tp);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _Xlr5PinoutPainter extends CustomPainter {
  const _Xlr5PinoutPainter({required this.loc});
  final AppLocalizations loc;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = const Color(0xFF0B0B0B);
    canvas.drawRect(Offset.zero & size, bg);

    final faint = Paint()
      ..color = Colors.white.withValues(alpha: 0.16)
      ..strokeWidth = 1;

    final step = size.shortestSide / 10;
    for (double x = 0; x <= size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), faint);
    }
    for (double y = 0; y <= size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), faint);
    }

    final cx = size.width * 0.32;
    final cy = size.height * 0.52;
    final r = size.shortestSide * 0.24;

    canvas.drawCircle(
      Offset(cx, cy),
      r,
      Paint()
        ..color = Colors.white.withValues(alpha: 0.22)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3,
    );

    final pins = <int, Offset>{
      1: Offset(cx, cy + r * 0.45),
      2: Offset(cx - r * 0.38, cy - r * 0.10),
      3: Offset(cx + r * 0.38, cy - r * 0.10),
      4: Offset(cx - r * 0.22, cy - r * 0.55),
      5: Offset(cx + r * 0.22, cy - r * 0.55),
    };

    for (final e in pins.entries) {
      canvas.drawCircle(
        e.value,
        r * 0.12,
        Paint()..color = Colors.white.withValues(alpha: 0.85),
      );
      final tp = _Text.tp(
        '${e.key}',
        fontSize: size.shortestSide * 0.055,
        color: const Color(0xFF0B0B0B),
        weight: FontWeight.w900,
      );
      _Text.center(
          canvas,
          Rect.fromCenter(center: e.value, width: r * 0.22, height: r * 0.22),
          tp);
    }

    final rightX = size.width * 0.58;
    final topY = size.height * 0.18;

    _label(
      canvas,
      Offset(rightX, topY),
      loc.aboutDmxPainterXlr5Title,
      size.shortestSide * 0.070,
      Colors.white.withValues(alpha: 0.94),
      FontWeight.w900,
    );

    final bullets = [
      loc.aboutDmxPainterPin1,
      loc.aboutDmxPainterPin2,
      loc.aboutDmxPainterPin3,
      loc.aboutDmxPainterPin45,
      loc.aboutDmxPainterXlr3Practice,
    ];
    _bulletBox(
        canvas,
        Rect.fromLTWH(rightX, topY + 22, size.width * 0.38, size.height * 0.60),
        bullets);
  }

  void _label(
      Canvas c, Offset p, String s, double fs, Color col, FontWeight w) {
    final tp = _Text.tp(s, fontSize: fs, color: col, weight: w);
    tp.paint(c, p);
  }

  void _bulletBox(Canvas c, Rect r, List<String> items) {
    final rr = RRect.fromRectAndRadius(r, const Radius.circular(14));
    c.drawRRect(rr, Paint()..color = Colors.black.withValues(alpha: 0.35));
    c.drawRRect(
      rr,
      Paint()
        ..color = Colors.white.withValues(alpha: 0.14)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5,
    );

    double y = r.top + 12;
    for (final s in items) {
      final tp = _Text.tp(
        '• $s',
        fontSize: r.shortestSide * 0.13,
        color: Colors.white.withValues(alpha: 0.86),
        weight: FontWeight.w700,
      );
      tp.paint(c, Offset(r.left + 12, y));
      y += tp.height + 6;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _TerminatorPainter extends CustomPainter {
  const _TerminatorPainter({required this.loc});
  final AppLocalizations loc;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = const Color(0xFF0B0B0B);
    canvas.drawRect(Offset.zero & size, bg);

    final faint = Paint()
      ..color = Colors.white.withValues(alpha: 0.16)
      ..strokeWidth = 1;

    final step = size.shortestSide / 10;
    for (double x = 0; x <= size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), faint);
    }
    for (double y = 0; y <= size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), faint);
    }

    final line = Paint()
      ..color = Colors.white.withValues(alpha: 0.88)
      ..strokeWidth = 2;

    final y = size.height * 0.55;
    final x0 = size.width * 0.10;
    final x1 = size.width * 0.78;

    canvas.drawLine(Offset(x0, y), Offset(x1, y), line);

    _box(canvas, size, Offset(size.width * 0.60, y),
        loc.aboutDmxPainterLastFixture,
        accent: false);
    _box(canvas, size, Offset(size.width * 0.84, y), loc.aboutDmxPainterTerm120,
        accent: true);

    _label(canvas, Offset(size.width * 0.10, size.height * 0.14),
        loc.aboutDmxPainterTerminationLine, size.shortestSide * 0.075);

    final rr = Rect.fromCenter(
      center: Offset(size.width * 0.84, size.height * 0.23),
      width: size.width * 0.20,
      height: size.height * 0.20,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(rr, const Radius.circular(14)),
      Paint()..color = Colors.black.withValues(alpha: 0.35),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(rr, const Radius.circular(14)),
      Paint()
        ..color = Colors.white.withValues(alpha: 0.14)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5,
    );

    final tp = _Text.tp(
      loc.aboutDmxPainter120Between,
      fontSize: size.shortestSide * 0.060,
      color: Colors.white.withValues(alpha: 0.90),
      weight: FontWeight.w900,
    );
    _Text.center(canvas, rr, tp);

    final tip = _Text.tp(
      loc.aboutDmxPainterOneTermination,
      fontSize: size.shortestSide * 0.055,
      color: Colors.white.withValues(alpha: 0.88),
      weight: FontWeight.w800,
    );
    _Text.paintLabel(
        canvas, Offset(size.width * 0.10, size.height * 0.70), tip);
  }

  void _box(Canvas canvas, Size size, Offset center, String label,
      {required bool accent}) {
    final w = size.width * 0.18;
    final h = size.height * 0.20;
    final rect = Rect.fromCenter(center: center, width: w, height: h);
    final rr = RRect.fromRectAndRadius(
        rect, Radius.circular(size.shortestSide * 0.05));

    final fill = Paint()
      ..color = accent
          ? Colors.redAccent.withValues(alpha: 0.18)
          : Colors.white.withValues(alpha: 0.08);

    final border = Paint()
      ..color = accent
          ? Colors.redAccent.withValues(alpha: 0.65)
          : Colors.white.withValues(alpha: 0.30)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    canvas.drawRRect(rr, fill);
    canvas.drawRRect(rr, border);

    final tp = _Text.tp(
      label,
      fontSize: size.shortestSide * 0.055,
      color: Colors.white.withValues(alpha: 0.95),
      weight: FontWeight.w900,
    );
    _Text.center(canvas, rect, tp);
  }

  void _label(Canvas canvas, Offset pos, String text, double fs) {
    final tp = _Text.tp(
      text,
      fontSize: fs,
      color: Colors.white.withValues(alpha: 0.94),
      weight: FontWeight.w900,
    );
    tp.paint(canvas, pos);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _IpDmxPainter extends CustomPainter {
  const _IpDmxPainter({required this.loc});
  final AppLocalizations loc;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = const Color(0xFF0B0B0B);
    canvas.drawRect(Offset.zero & size, bg);

    final faint = Paint()
      ..color = Colors.white.withValues(alpha: 0.16)
      ..strokeWidth = 1;

    final step = size.shortestSide / 10;
    for (double x = 0; x <= size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), faint);
    }
    for (double y = 0; y <= size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), faint);
    }

    final stroke = Paint()
      ..color = Colors.white.withValues(alpha: 0.88)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    final console = Offset(size.width * 0.16, size.height * 0.32);
    final sw = Offset(size.width * 0.42, size.height * 0.32);

    final node1 = Offset(size.width * 0.70, size.height * 0.22);
    final node2 = Offset(size.width * 0.70, size.height * 0.52);

    canvas.drawLine(console, sw, stroke);
    canvas.drawLine(sw, node1, stroke);
    canvas.drawLine(sw, node2, stroke);

    final dmxStroke = Paint()
      ..color = Colors.white.withValues(alpha: 0.45)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    final fix1 = Offset(size.width * 0.88, size.height * 0.16);
    final fix2 = Offset(size.width * 0.88, size.height * 0.28);
    final fix3 = Offset(size.width * 0.88, size.height * 0.46);
    final fix4 = Offset(size.width * 0.88, size.height * 0.58);

    canvas.drawLine(node1, fix1, dmxStroke);
    canvas.drawLine(node1, fix2, dmxStroke);
    canvas.drawLine(node2, fix3, dmxStroke);
    canvas.drawLine(node2, fix4, dmxStroke);

    _box(canvas, size, console, loc.aboutDmxPainterConsoleIp, accent: false);
    _box(canvas, size, sw, loc.aboutDmxPainterSwitchSacn, accent: true);
    _box(canvas, size, node1, loc.aboutDmxPainterNode1, accent: false);
    _box(canvas, size, node2, loc.aboutDmxPainterNode2, accent: false);

    _small(canvas, size, fix1, loc.aboutDmxPainterFix);
    _small(canvas, size, fix2, loc.aboutDmxPainterFix);
    _small(canvas, size, fix3, loc.aboutDmxPainterFix);
    _small(canvas, size, fix4, loc.aboutDmxPainterFix);

    final tp = _Text.tp(
      loc.aboutDmxPainterManyUniverses,
      fontSize: size.shortestSide * 0.07,
      color: Colors.white.withValues(alpha: 0.90),
      weight: FontWeight.w900,
    );
    _Text.paintLabel(canvas, Offset(size.width * 0.08, size.height * 0.70), tp);
  }

  void _box(Canvas canvas, Size size, Offset center, String label,
      {required bool accent}) {
    final w = size.width * 0.22;
    final h = size.height * 0.22;
    final rect = Rect.fromCenter(center: center, width: w, height: h);
    final rr = RRect.fromRectAndRadius(
        rect, Radius.circular(size.shortestSide * 0.05));

    final fill = Paint()
      ..color = accent
          ? const Color(0xFF1E88E5).withValues(alpha: 0.18)
          : Colors.white.withValues(alpha: 0.08);

    final border = Paint()
      ..color = accent
          ? const Color(0xFF1E88E5).withValues(alpha: 0.60)
          : Colors.white.withValues(alpha: 0.30)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    canvas.drawRRect(rr, fill);
    canvas.drawRRect(rr, border);

    final tp = _Text.tp(
      label,
      fontSize: size.shortestSide * 0.055,
      color: Colors.white.withValues(alpha: 0.95),
      weight: FontWeight.w900,
    );
    _Text.center(canvas, rect, tp);
  }

  void _small(Canvas canvas, Size size, Offset center, String label) {
    final w = size.width * 0.08;
    final h = size.height * 0.12;
    final rect = Rect.fromCenter(center: center, width: w, height: h);
    final rr = RRect.fromRectAndRadius(
        rect, Radius.circular(size.shortestSide * 0.04));

    canvas.drawRRect(rr, Paint()..color = Colors.white.withValues(alpha: 0.07));
    canvas.drawRRect(
      rr,
      Paint()
        ..color = Colors.white.withValues(alpha: 0.20)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2,
    );

    final tp = _Text.tp(
      label,
      fontSize: size.shortestSide * 0.05,
      color: Colors.white.withValues(alpha: 0.90),
      weight: FontWeight.w900,
    );
    _Text.center(canvas, rect, tp);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _Node {
  const _Node(this.label, this.pos, {this.isTerminator = false});
  final String label;
  final Offset pos;
  final bool isTerminator;
}

class _Text {
  static TextPainter tp(
    String s, {
    required double fontSize,
    required Color color,
    required FontWeight weight,
  }) {
    final t = TextPainter(
      text: TextSpan(
        text: s,
        style: TextStyle(
          fontSize: fontSize,
          color: color,
          fontWeight: weight,
          fontFamily: 'monospace',
          height: 1.15,
        ),
      ),
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.left,
    );
    t.layout();
    return t;
  }

  static void center(Canvas canvas, Rect rect, TextPainter tp) {
    final dx = rect.left + (rect.width - tp.width) / 2;
    final dy = rect.top + (rect.height - tp.height) / 2;
    tp.paint(canvas, Offset(dx, dy));
  }

  static void paintLabel(Canvas canvas, Offset pos, TextPainter tp) {
    final pad = 10.0;
    final r = RRect.fromRectAndRadius(
      Rect.fromLTWH(pos.dx, pos.dy, tp.width + pad * 2, tp.height + pad * 2),
      const Radius.circular(12),
    );

    canvas.drawRRect(r, Paint()..color = Colors.black.withValues(alpha: 0.45));
    canvas.drawRRect(
      r,
      Paint()
        ..color = Colors.white.withValues(alpha: 0.14)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5,
    );

    tp.paint(canvas, Offset(pos.dx + pad, pos.dy + pad));
  }
}
